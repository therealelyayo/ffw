<?php

declare(strict_types=1);

namespace AsyncAws\Core\Exception;

class UnparsableResponse extends \RuntimeException implements Exception
{
}
